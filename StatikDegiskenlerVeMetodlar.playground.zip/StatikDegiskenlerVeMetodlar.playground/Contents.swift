import UIKit

//statik değişkenler ve metodlar
class ASinifi {
   static var x = 10  //Önceki kodda okuma satırı haline getirdiğimiz ve static olan kısma bakmak istediğimiz için var ve func alanların başına static ekledik.
    static func metod () {
        print ("Metod çalıştı")
    }
}

/*let a = ASinifi()
print (a.x)
a.metod()
print (ASinifi().x) //sanal nesne object - isimsiz
ASinifi().metod()*/


let a = ASinifi()
print (ASinifi.x)
ASinifi.metod()
